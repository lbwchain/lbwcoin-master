Sample configuration files for:

SystemD: lbwcoind.service
Upstart: lbwcoind.conf
OpenRC:  lbwcoind.openrc
         lbwcoind.openrcconf
CentOS:  lbwcoind.init
OS X:    org.lbwcoin.lbwcoind.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.

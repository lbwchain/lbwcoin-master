
Debian
====================
This directory contains files used to package lbwcoind/lbwcoin-qt
for Debian-based Linux systems. If you compile lbwcoind/lbwcoin-qt yourself, there are some useful files here.

## lbwcoin: URI support ##


lbwcoin-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install lbwcoin-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your lbwcoin-qt binary to `/usr/bin`
and the `../../share/pixmaps/lbwcoin128.png` to `/usr/share/pixmaps`

lbwcoin-qt.protocol (KDE)

